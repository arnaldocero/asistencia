<?php
include('../ajax/db_connect.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Datos del formulario
$nombre_nino = $_POST['fname'];
$apellido_nino = $_POST['lname'];
$fecha_nacimiento = $_POST['fechaNacimiento'];
$nombre_padre = $_POST['padrename'];
$telefono_delpadre = $_POST['padrephone'];
$direccion = $_POST['direccion'];

// Prepara la consulta SQL
$stmt = $conn->prepare("INSERT INTO Ninos (nombre, apellido, fecha_nacimiento, nombre_padre, telefono_padre, direccion) VALUES (?, ?, ?, ?, ?, ?)");

if ($stmt === false) {
    echo json_encode(['status' => 'error', 'message' => 'Error al preparar la consulta: ' . $conn->error]);
    exit();
}

// Asocia los parámetros con la consulta
$stmt->bind_param("ssssss", $nombre_nino, $apellido_nino, $fecha_nacimiento, $nombre_padre, $telefono_delpadre, $direccion);

// Ejecuta la consulta
if ($stmt->execute()) {
    echo json_encode(['status' => 'success', 'message' => 'Niño registrado exitosamente']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Error al registrar el niño: ' . $stmt->error]);
}

// Cierra el statement y la conexión
$stmt->close();
$conn->close();
}
?>