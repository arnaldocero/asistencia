<?php
include('../ajax/db_connect.php');  // Incluye tu archivo de conexión

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_nino = $_POST['id_nino'];
    $estado = $_POST['estado'];
    date_default_timezone_set('America/Bogota');
    $fecha_sistema = date('Y-m-d');  // Fecha del sistema (hoy)

    // Validación básica
    if (empty($id_nino) || empty($estado)) {
        echo json_encode(['status' => 'error', 'message' => 'ID de niño y estado son obligatorios']);
        exit();
    }

    // Preparar la consulta de actualización
    $stmt = $conn->prepare("UPDATE asistencia SET estado = ? WHERE id_nino = ? AND fecha_asistencia = ?");
    $stmt->bind_param("si", $estado, $id_nino,$fecha_sistema);

    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'Estado actualizado correctamente']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Error al actualizar el estado: ' . $stmt->error]);
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(['status' => 'error', 'message' => 'Método no permitido']);
}
?>