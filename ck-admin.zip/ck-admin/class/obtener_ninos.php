<?php
// Conexión a la base de datos
include('../ajax/db_connect.php');  // Incluye tu archivo de conexión

$sql = "SELECT id_nino, nombre, apellido, nombre_padre FROM Ninos";
$result = $conn->query($sql);
$datos = array();
if ($result->num_rows > 0) {
    // Recorre cada fila y guarda los datos en un array
    while ($row = $result->fetch_assoc()) {
        $datos[] = $row;  // Guarda cada fila en el array
    }

    // Devuelve los datos en formato JSON
    echo json_encode(['status' => 'success', 'data' => $datos]);
} else {
    // En caso de que no haya datos disponibles
    echo json_encode(['status' => 'error', 'message' => 'No hay datos disponibles']);
}

$conn->close();
?>